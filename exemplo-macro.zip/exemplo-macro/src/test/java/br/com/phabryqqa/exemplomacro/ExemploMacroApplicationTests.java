package br.com.phabryqqa.exemplomacro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExemploMacroApplicationTests {

	@Test
	void contextLoads() {
	}

}
